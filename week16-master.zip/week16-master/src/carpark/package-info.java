/**
 * Demonstration package using monitors to implement a simple car park system.
 *
 * @author Hugh Osborne
 * @version February 2020
 */

package carpark;