/**
 * Implements and uses resource managers.
 *
 * @author Hugh Osborne
 * @version February 2020
 */
package resourceManager;