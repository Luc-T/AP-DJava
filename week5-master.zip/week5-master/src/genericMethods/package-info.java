/**
 * This package contains some examples of generic methods.
 *
 * @author Hugh Osborne
 * @version September 2019
 */

package genericMethods;
