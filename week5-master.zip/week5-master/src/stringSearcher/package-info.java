/**
 * String searchers will search for the first occurrence of a given substring in superstrings.
 *
 * @author Hugh Osborne
 * @version October 2019
 */
package stringSearcher;